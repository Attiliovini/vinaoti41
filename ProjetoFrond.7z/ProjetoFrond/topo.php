<a href="#entrar">Entrar</a>
<a href="/vinaoti41/ProjetoFrond/cadastrar.php">Cadastre-se</a>
</div>
<div class="fundocinza">
    <img class="logo" src="imagens/logo.png">

    <div class="icon-container">
        <div class="icon">
            <a href="betour.php"><img class="logo2" src="imagens/home.png"></a>
            <div>
                <a href="betour.php">INICIO</a>
            </div>
        </div>
        <div class="icon">
            <a href="#"><img class="logo2" src="imagens/empresa.png"></a>
            <div>
                <a>EMPRESA</a>
            </div>
        </div>
        <div class="icon">
            <a href="pacotes.php"><img class="logo2" src="imagens/viagem.png"></a>
            <div>
                <a>PACOTES</a>
            </div>
        </div>
        <div class="icon">
            <a href="#"><img class="logo2" src="imagens/ilha.png"></a>
            <div>
                <a>BATE E VOLTA</a>
            </div>
        </div>
        <div class="icon">
            <a href="#"><img class="logo2" src="imagens/contato.png"></a>
            <div>
                <a>CONTATO</a>
            </div>
        </div>

    </div>